
#!/bin/bash

echo "Preparing SoulNote for release..."

# Create release directory
mkdir -p release

# Clean the project
./gradlew clean

# Build the APK
echo "Building APK..."
./gradlew assembleDebug

# Copy important files to release directory
cp app/build/outputs/apk/debug/app-debug.apk release/SoulNote-v2.0.0-debug.apk 2>/dev/null || echo "APK not found - run gradle build manually"

# Create source code archive
echo "Creating source code archive..."
zip -r release/SoulNote-v2.0.0-source.zip . \
    -x "*.git*" \
    -x "*build*" \
    -x "*.gradle/wrapper*" \
    -x "*local.properties*" \
    -x "*/.idea/*" \
    -x "*/release/*"

# Create installation package with all necessary files
echo "Creating complete installation package..."
mkdir -p release/SoulNote-Complete
cp -r . release/SoulNote-Complete/
cd release/SoulNote-Complete/

# Clean up unnecessary files
rm -rf .git build .gradle .idea local.properties
rm -rf app/build lib_module/*/build
rm -rf release

cd ../..

# Create final ZIP
zip -r release/SoulNote-v2.0.0-complete.zip release/SoulNote-Complete/

# Clean up temporary directory
rm -rf release/SoulNote-Complete

echo "Release preparation completed!"
echo "Files created in 'release' directory:"
ls -la release/
