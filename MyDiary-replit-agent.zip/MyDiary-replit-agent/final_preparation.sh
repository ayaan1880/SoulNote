
#!/bin/bash

echo "🚀 Final SoulNote App Preparation"
echo "=================================="

# Step 1: Clean and prepare the project
echo "📦 Cleaning project..."
./gradlew clean

# Step 2: Update dependencies and sync
echo "🔄 Syncing dependencies..."
./gradlew build --refresh-dependencies

# Step 3: Run tests (if any)
echo "🧪 Running tests..."
./gradlew test || echo "⚠️  No tests found or tests failed"

# Step 4: Build APK
echo "🔨 Building APK..."
./gradlew assembleDebug

# Step 5: Check for common issues
echo "🔍 Checking for common issues..."

# Check if APK was built successfully
if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo "✅ APK built successfully!"
    APK_SIZE=$(du -h app/build/outputs/apk/debug/app-debug.apk | cut -f1)
    echo "📏 APK size: $APK_SIZE"
else
    echo "❌ APK build failed!"
fi

# Step 6: Create final release package
echo "📁 Creating final release package..."
mkdir -p final_release

# Copy APK
cp app/build/outputs/apk/debug/app-debug.apk final_release/SoulNote-v2.0.0.apk 2>/dev/null || echo "⚠️  APK not found"

# Create source code ZIP (excluding build files and git)
echo "📦 Creating source code archive..."
zip -r final_release/SoulNote-Source-v2.0.0.zip . \
    -x "*.git*" \
    -x "*build/*" \
    -x "*/.gradle/*" \
    -x "*/local.properties" \
    -x "*/.idea/*" \
    -x "*/final_release/*" \
    -x "*/release/*"

# Step 7: Create GitHub-ready package
echo "🐙 Creating GitHub-ready package..."
mkdir -p final_release/GitHub-Upload
cp -r . final_release/GitHub-Upload/
cd final_release/GitHub-Upload/

# Clean up for GitHub
rm -rf .git .gradle .idea build */build local.properties final_release release
rm -f *.sh

cd ../..

# Create GitHub ZIP
zip -r final_release/SoulNote-GitHub-v2.0.0.zip final_release/GitHub-Upload/
rm -rf final_release/GitHub-Upload

# Step 8: Generate checksum
echo "🔐 Generating checksums..."
cd final_release
for file in *.zip *.apk; do
    if [ -f "$file" ]; then
        sha256sum "$file" > "$file.sha256"
    fi
done
cd ..

# Step 9: Create installation instructions
cat > final_release/INSTALLATION.md << 'EOF'
# SoulNote Installation Guide

## Quick Start
1. Download `SoulNote-v2.0.0.apk`
2. Enable "Install from Unknown Sources" in Android Settings
3. Install the APK
4. Open SoulNote and start journaling!

## For Developers
1. Download `SoulNote-Source-v2.0.0.zip`
2. Extract the archive
3. Open in Android Studio
4. Build and run: `./gradlew assembleDebug`

## For GitHub Upload
1. Use `SoulNote-GitHub-v2.0.0.zip`
2. Extract and upload to your repository
3. All files are ready for GitHub

## Verification
- Check SHA256 checksums in `.sha256` files
- APK is debug-signed for testing

## System Requirements
- Android 5.0 (API 21) or higher
- 100MB free storage
- Internet for cloud features (optional)

## Support
- GitHub: [Issues](https://github.com/yourusername/SoulNote/issues)
- Email: support@soulnote.app
EOF

# Step 10: Final summary
echo ""
echo "🎉 SoulNote App Preparation Complete!"
echo "====================================="
echo ""
echo "📁 Files created in 'final_release' directory:"
ls -la final_release/
echo ""
echo "📱 Your app is ready for:"
echo "   ✅ Installation on Android devices"
echo "   ✅ Upload to GitHub"
echo "   ✅ Distribution to users"
echo "   ✅ Development and modification"
echo ""
echo "🔧 Next steps:"
echo "   1. Test the APK on your Android device"
echo "   2. Upload SoulNote-GitHub-v2.0.0.zip to your GitHub repository"
echo "   3. Share the APK with users for testing"
echo "   4. Continue development with the source code"
echo ""
echo "✨ SoulNote - Your thoughts, securely stored!"
