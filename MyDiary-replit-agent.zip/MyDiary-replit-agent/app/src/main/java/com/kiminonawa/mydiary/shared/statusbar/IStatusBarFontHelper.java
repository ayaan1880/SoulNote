package com.soulnote.app.shared.statusbar;

import android.app.Activity;

/**
 * * Ref:https://github.com/zouzhenglu/zouzhenglu.github.io
 * Created by daxia on 2016/12/7.
 */

public interface IStatusBarFontHelper {
    boolean setStatusBarLightMode(Activity activity, boolean isFontColorDark);
}

