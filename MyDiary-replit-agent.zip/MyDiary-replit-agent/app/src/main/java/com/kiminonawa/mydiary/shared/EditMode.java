package com.soulnote.app.shared;

/**
 * Created by daxia on 2016/11/7.
 */

public interface EditMode {
    boolean isEditMode();
    void setEditMode(boolean editMode);
}
