
package com.soulnote.app.models;

import java.util.Date;
import java.util.List;

public class Entry {
    private long id;
    private String title;
    private String content;
    private Date dateCreated;
    private Date dateModified;
    private String mood;
    private String weather;
    private String location;
    private List<String> tags;
    private List<String> photos;
    private boolean isEncrypted;
    private boolean isFavorite;
    private String color;
    private float rating;
    
    // Constructors
    public Entry() {
        this.dateCreated = new Date();
        this.dateModified = new Date();
        this.isEncrypted = false;
        this.isFavorite = false;
        this.rating = 0.0f;
    }
    
    public Entry(String title, String content) {
        this();
        this.title = title;
        this.content = content;
    }
    
    // Getters and Setters
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    
    public Date getDateCreated() { return dateCreated; }
    public void setDateCreated(Date dateCreated) { this.dateCreated = dateCreated; }
    
    public Date getDateModified() { return dateModified; }
    public void setDateModified(Date dateModified) { this.dateModified = dateModified; }
    
    public String getMood() { return mood; }
    public void setMood(String mood) { this.mood = mood; }
    
    public String getWeather() { return weather; }
    public void setWeather(String weather) { this.weather = weather; }
    
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    
    public List<String> getTags() { return tags; }
    public void setTags(List<String> tags) { this.tags = tags; }
    
    public List<String> getPhotos() { return photos; }
    public void setPhotos(List<String> photos) { this.photos = photos; }
    
    public boolean isEncrypted() { return isEncrypted; }
    public void setEncrypted(boolean encrypted) { isEncrypted = encrypted; }
    
    public boolean isFavorite() { return isFavorite; }
    public void setFavorite(boolean favorite) { isFavorite = favorite; }
    
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    
    public float getRating() { return rating; }
    public void setRating(float rating) { this.rating = rating; }
}
