
package com.soulnote.app.shared;

public class Constants {
    public static final String APP_NAME = "SoulNote";
    public static final String DB_NAME = "soulnote.db";
    public static final int DB_VERSION = 8;
    
    // Theme constants
    public static final String THEME_BRIGHT = "bright";
    public static final String THEME_DARK = "dark";
    public static final String THEME_AMOLED = "amoled";
    
    // Backup constants
    public static final String BACKUP_FOLDER = "SoulNote_Backup";
    public static final String BACKUP_FILE_EXTENSION = ".snb";
    
    // Encryption constants
    public static final String ENCRYPTION_ALGORITHM = "AES/GCM/NoPadding";
    public static final int KEY_LENGTH = 256;
    
    // Social login
    public static final String GOOGLE_CLIENT_ID = "your-google-client-id";
    public static final String FACEBOOK_APP_ID = "your-facebook-app-id";
}
