
package com.soulnote.app.ai;

import android.content.Context;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.concurrent.CompletableFuture;

public class GeminiAIService {
    private static final String GEMINI_API_KEY = "AIzaSyBjWalu4KTsvipSbrTlbUoiFEIiV2slq7U";
    private static final String GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + GEMINI_API_KEY;
    
    private OkHttpClient client;
    
    public GeminiAIService() {
        this.client = new OkHttpClient();
    }
    
    public interface AICallback {
        void onSuccess(String response);
        void onError(String error);
    }
    
    public void analyzeMood(String diaryText, AICallback callback) {
        try {
            JSONObject requestBody = new JSONObject();
            JSONArray contents = new JSONArray();
            JSONObject content = new JSONObject();
            JSONArray parts = new JSONArray();
            JSONObject part = new JSONObject();
            
            part.put("text", "Analyze the mood and sentiment of this diary entry and suggest a mood emoji. Text: " + diaryText);
            parts.put(part);
            content.put("parts", parts);
            contents.put(content);
            requestBody.put("contents", contents);
            
            makeRequest(requestBody.toString(), callback);
        } catch (JSONException e) {
            callback.onError("Error creating request: " + e.getMessage());
        }
    }
    
    public void generateInsights(String diaryText, AICallback callback) {
        try {
            JSONObject requestBody = new JSONObject();
            JSONArray contents = new JSONArray();
            JSONObject content = new JSONObject();
            JSONArray parts = new JSONArray();
            JSONObject part = new JSONObject();
            
            part.put("text", "Provide thoughtful insights and reflection questions based on this diary entry. Be supportive and constructive: " + diaryText);
            parts.put(part);
            content.put("parts", parts);
            contents.put(content);
            requestBody.put("contents", contents);
            
            makeRequest(requestBody.toString(), callback);
        } catch (JSONException e) {
            callback.onError("Error creating request: " + e.getMessage());
        }
    }
    
    public void suggestTags(String diaryText, AICallback callback) {
        try {
            JSONObject requestBody = new JSONObject();
            JSONArray contents = new JSONArray();
            JSONObject content = new JSONObject();
            JSONArray parts = new JSONArray();
            JSONObject part = new JSONObject();
            
            part.put("text", "Suggest 3-5 relevant tags for this diary entry. Return only the tags separated by commas: " + diaryText);
            parts.put(part);
            content.put("parts", parts);
            contents.put(content);
            requestBody.put("contents", contents);
            
            makeRequest(requestBody.toString(), callback);
        } catch (JSONException e) {
            callback.onError("Error creating request: " + e.getMessage());
        }
    }
    
    private void makeRequest(String requestBody, AICallback callback) {
        RequestBody body = RequestBody.create(requestBody, MediaType.parse("application/json"));
        Request request = new Request.Builder()
                .url(GEMINI_API_URL)
                .post(body)
                .addHeader("Content-Type", "application/json")
                .build();
        
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onError("Network error: " + e.getMessage());
            }
            
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        String responseBody = response.body().string();
                        JSONObject jsonResponse = new JSONObject(responseBody);
                        JSONArray candidates = jsonResponse.getJSONArray("candidates");
                        if (candidates.length() > 0) {
                            JSONObject candidate = candidates.getJSONObject(0);
                            JSONObject content = candidate.getJSONObject("content");
                            JSONArray parts = content.getJSONArray("parts");
                            if (parts.length() > 0) {
                                String text = parts.getJSONObject(0).getString("text");
                                callback.onSuccess(text);
                            } else {
                                callback.onError("No response text found");
                            }
                        } else {
                            callback.onError("No candidates in response");
                        }
                    } catch (JSONException e) {
                        callback.onError("Error parsing response: " + e.getMessage());
                    }
                } else {
                    callback.onError("API request failed: " + response.message());
                }
            }
        });
    }
}
package com.soulnote.app.ai;

import android.content.Context;
import android.os.AsyncTask;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class GeminiAIService {
    private static final String GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent";
    private String apiKey;
    
    public interface AICallback {
        void onSuccess(String response);
        void onError(String error);
    }
    
    public GeminiAIService(String apiKey) {
        this.apiKey = apiKey;
    }
    
    public void analyzeMood(String entryText, AICallback callback) {
        new AIAnalysisTask(callback, "mood").execute(entryText);
    }
    
    public void generateWritingPrompt(AICallback callback) {
        new AIAnalysisTask(callback, "prompt").execute("");
    }
    
    public void summarizeEntry(String entryText, AICallback callback) {
        new AIAnalysisTask(callback, "summary").execute(entryText);
    }
    
    private class AIAnalysisTask extends AsyncTask<String, Void, String> {
        private AICallback callback;
        private String analysisType;
        private String errorMessage;
        
        public AIAnalysisTask(AICallback callback, String analysisType) {
            this.callback = callback;
            this.analysisType = analysisType;
        }
        
        @Override
        protected String doInBackground(String... params) {
            try {
                String prompt = buildPrompt(analysisType, params[0]);
                return makeAPICall(prompt);
            } catch (Exception e) {
                errorMessage = e.getMessage();
                return null;
            }
        }
        
        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                callback.onSuccess(result);
            } else {
                callback.onError(errorMessage != null ? errorMessage : "Unknown error");
            }
        }
        
        private String buildPrompt(String type, String text) {
            switch (type) {
                case "mood":
                    return "Analyze the mood of this diary entry and return only one word (happy, sad, excited, anxious, peaceful, etc.): " + text;
                case "prompt":
                    return "Generate a creative writing prompt for a diary entry. Keep it under 50 words.";
                case "summary":
                    return "Summarize this diary entry in 2-3 sentences: " + text;
                default:
                    return text;
            }
        }
        
        private String makeAPICall(String prompt) throws Exception {
            URL url = new URL(GEMINI_API_URL + "?key=" + apiKey);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            
            JsonObject requestBody = new JsonObject();
            JsonObject contents = new JsonObject();
            JsonObject parts = new JsonObject();
            parts.addProperty("text", prompt);
            contents.add("parts", new Gson().toJsonTree(new JsonObject[]{parts}));
            requestBody.add("contents", new Gson().toJsonTree(new JsonObject[]{contents}));
            
            OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
            writer.write(requestBody.toString());
            writer.flush();
            
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            
            reader.close();
            writer.close();
            
            // Parse response and extract text
            JsonObject responseObj = new Gson().fromJson(response.toString(), JsonObject.class);
            return responseObj.getAsJsonArray("candidates")
                    .get(0).getAsJsonObject()
                    .getAsJsonObject("content")
                    .getAsJsonArray("parts")
                    .get(0).getAsJsonObject()
                    .get("text").getAsString();
        }
    }
}
