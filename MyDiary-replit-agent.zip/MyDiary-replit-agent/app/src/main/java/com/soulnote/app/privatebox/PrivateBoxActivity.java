
package com.soulnote.app.privatebox;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.soulnote.app.R;
import com.soulnote.app.database.DBManager;
import com.soulnote.app.security.EncryptionHelper;
import java.util.ArrayList;
import java.util.concurrent.Executor;

public class PrivateBoxActivity extends AppCompatActivity {
    
    private RecyclerView recyclerViewPrivateNotes;
    private FloatingActionButton fabAddPrivateNote;
    private PrivateNoteAdapter adapter;
    private ArrayList<PrivateNote> privateNotes;
    private DBManager dbManager;
    private EncryptionHelper encryptionHelper;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private_box);
        
        initViews();
        setupBiometricAuthentication();
        dbManager = new DBManager(this);
        encryptionHelper = new EncryptionHelper();
    }
    
    private void initViews() {
        recyclerViewPrivateNotes = findViewById(R.id.recycler_private_notes);
        fabAddPrivateNote = findViewById(R.id.fab_add_private_note);
        
        privateNotes = new ArrayList<>();
        adapter = new PrivateNoteAdapter(this, privateNotes);
        recyclerViewPrivateNotes.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewPrivateNotes.setAdapter(adapter);
        
        fabAddPrivateNote.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddPrivateNoteActivity.class);
            startActivity(intent);
        });
    }
    
    private void setupBiometricAuthentication() {
        BiometricManager biometricManager = BiometricManager.from(this);
        
        switch (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)) {
            case BiometricManager.BIOMETRIC_SUCCESS:
                authenticateUser();
                break;
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                Toast.makeText(this, "No biometric features available", Toast.LENGTH_SHORT).show();
                finish();
                break;
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                Toast.makeText(this, "Biometric features are currently unavailable", Toast.LENGTH_SHORT).show();
                finish();
                break;
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                Toast.makeText(this, "Please set up biometric authentication", Toast.LENGTH_SHORT).show();
                finish();
                break;
        }
    }
    
    private void authenticateUser() {
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt biometricPrompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override
            public void onAuthenticationError(int errorCode, CharSequence errString) {
                super.onAuthenticationError(errorCode, errString);
                Toast.makeText(PrivateBoxActivity.this, "Authentication error: " + errString, Toast.LENGTH_SHORT).show();
                finish();
            }
            
            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                super.onAuthenticationSucceeded(result);
                Toast.makeText(PrivateBoxActivity.this, "Authentication succeeded", Toast.LENGTH_SHORT).show();
                loadPrivateNotes();
            }
            
            @Override
            public void onAuthenticationFailed() {
                super.onAuthenticationFailed();
                Toast.makeText(PrivateBoxActivity.this, "Authentication failed", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
        
        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Private Box Access")
                .setSubtitle("Use your biometric credential to unlock private notes")
                .setNegativeButtonText("Cancel")
                .build();
        
        biometricPrompt.authenticate(promptInfo);
    }
    
    private void loadPrivateNotes() {
        // Load encrypted private notes from database
        // Implementation would include decryption logic
    }
}

class PrivateNote {
    private long id;
    private String title;
    private String content;
    private String password;
    private long timestamp;
    
    // Constructors, getters, and setters
    public PrivateNote(long id, String title, String content, String password, long timestamp) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.password = password;
        this.timestamp = timestamp;
    }
    
    // Getters and setters
    public long getId() { return id; }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public String getPassword() { return password; }
    public long getTimestamp() { return timestamp; }
}
