
package com.soulnote.app.backup;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;
import java.io.ByteArrayContent;
import java.io.IOException;
import java.util.Collections;

public class GoogleDriveBackupService {
    private Context context;
    private Drive driveService;
    private GoogleSignInClient googleSignInClient;
    
    public interface BackupCallback {
        void onSuccess(String message);
        void onError(String error);
        void onProgress(String status);
    }
    
    public GoogleDriveBackupService(Context context) {
        this.context = context;
        setupGoogleSignIn();
    }
    
    private void setupGoogleSignIn() {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestScopes(new com.google.android.gms.common.api.Scope(DriveScopes.DRIVE_FILE))
                .build();
        
        googleSignInClient = GoogleSignIn.getClient(context, gso);
    }
    
    public Intent getSignInIntent() {
        return googleSignInClient.getSignInIntent();
    }
    
    public void setupDriveService(GoogleSignInAccount account) {
        GoogleAccountCredential credential = GoogleAccountCredential.usingOAuth2(
                context, Collections.singleton(DriveScopes.DRIVE_FILE));
        credential.setSelectedAccount(account.getAccount());
        
        driveService = new Drive.Builder(
                AndroidHttp.newCompatibleTransport(),
                new GsonFactory(),
                credential)
                .setApplicationName("SoulNote")
                .build();
    }
    
    public void backupToGoogleDrive(String backupData, BackupCallback callback) {
        new BackupTask(callback).execute(backupData);
    }
    
    public void restoreFromGoogleDrive(BackupCallback callback) {
        new RestoreTask(callback).execute();
    }
    
    private class BackupTask extends AsyncTask<String, String, String> {
        private BackupCallback callback;
        private Exception exception;
        
        public BackupTask(BackupCallback callback) {
            this.callback = callback;
        }
        
        @Override
        protected void onPreExecute() {
            callback.onProgress("Starting backup to Google Drive...");
        }
        
        @Override
        protected String doInBackground(String... backupData) {
            try {
                publishProgress("Uploading backup file...");
                
                File fileMetadata = new File();
                fileMetadata.setName("soulnote_backup_" + System.currentTimeMillis() + ".json");
                fileMetadata.setParents(Collections.singletonList("appDataFolder"));
                
                ByteArrayContent mediaContent = new ByteArrayContent("application/json", backupData[0].getBytes());
                
                File file = driveService.files().create(fileMetadata, mediaContent)
                        .setFields("id")
                        .execute();
                
                return "Backup successful. File ID: " + file.getId();
            } catch (IOException e) {
                exception = e;
                return null;
            }
        }
        
        @Override
        protected void onProgressUpdate(String... progress) {
            callback.onProgress(progress[0]);
        }
        
        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                callback.onSuccess(result);
            } else {
                callback.onError("Backup failed: " + (exception != null ? exception.getMessage() : "Unknown error"));
            }
        }
    }
    
    private class RestoreTask extends AsyncTask<Void, String, String> {
        private BackupCallback callback;
        private Exception exception;
        
        public RestoreTask(BackupCallback callback) {
            this.callback = callback;
        }
        
        @Override
        protected void onPreExecute() {
            callback.onProgress("Searching for backup files...");
        }
        
        @Override
        protected String doInBackground(Void... voids) {
            try {
                publishProgress("Finding latest backup...");
                
                FileList result = driveService.files().list()
                        .setQ("name contains 'soulnote_backup' and parents in 'appDataFolder'")
                        .setOrderBy("createdTime desc")
                        .setPageSize(1)
                        .setFields("files(id, name)")
                        .execute();
                
                if (result.getFiles().isEmpty()) {
                    return "No backup files found";
                }
                
                File backupFile = result.getFiles().get(0);
                publishProgress("Downloading backup: " + backupFile.getName());
                
                String content = driveService.files().get(backupFile.getId())
                        .executeMediaAsInputStream()
                        .toString();
                
                return content;
            } catch (IOException e) {
                exception = e;
                return null;
            }
        }
        
        @Override
        protected void onProgressUpdate(String... progress) {
            callback.onProgress(progress[0]);
        }
        
        @Override
        protected void onPostExecute(String result) {
            if (result != null && !result.equals("No backup files found")) {
                callback.onSuccess(result);
            } else {
                callback.onError(result != null ? result : "Restore failed: " + (exception != null ? exception.getMessage() : "Unknown error"));
            }
        }
    }
}
