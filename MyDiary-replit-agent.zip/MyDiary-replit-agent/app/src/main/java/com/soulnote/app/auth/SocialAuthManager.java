
package com.soulnote.app.auth;

import android.app.Activity;
import android.content.Intent;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.Task;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;

public class SocialAuthManager {
    private static final int RC_SIGN_IN = 9001;
    
    private GoogleSignInClient googleSignInClient;
    private CallbackManager facebookCallbackManager;
    private AuthCallback authCallback;
    
    public interface AuthCallback {
        void onAuthSuccess(String provider, String userId, String displayName, String email);
        void onAuthError(String error);
    }
    
    public SocialAuthManager(Activity activity, AuthCallback callback) {
        this.authCallback = callback;
        setupGoogleAuth(activity);
        setupFacebookAuth();
    }
    
    private void setupGoogleAuth(Activity activity) {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestProfile()
                .build();
        googleSignInClient = GoogleSignIn.getClient(activity, gso);
    }
    
    private void setupFacebookAuth() {
        facebookCallbackManager = CallbackManager.Factory.create();
        LoginManager.getInstance().registerCallback(facebookCallbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        // Handle Facebook login success
                        authCallback.onAuthSuccess("facebook", 
                            loginResult.getAccessToken().getUserId(), 
                            "", "");
                    }
                    
                    @Override
                    public void onCancel() {
                        authCallback.onAuthError("Facebook login cancelled");
                    }
                    
                    @Override
                    public void onError(FacebookException exception) {
                        authCallback.onAuthError("Facebook login error: " + exception.getMessage());
                    }
                });
    }
    
    public void signInWithGoogle(Activity activity) {
        Intent signInIntent = googleSignInClient.getSignInIntent();
        activity.startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    
    public void signInWithFacebook() {
        LoginManager.getInstance().logInWithReadPermissions(
            (Activity) authCallback, java.util.Arrays.asList("email", "public_profile"));
    }
    
    public void handleActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleGoogleSignInResult(task);
        } else {
            facebookCallbackManager.onActivityResult(requestCode, resultCode, data);
        }
    }
    
    private void handleGoogleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult();
            authCallback.onAuthSuccess("google", 
                account.getId(), 
                account.getDisplayName(), 
                account.getEmail());
        } catch (Exception e) {
            authCallback.onAuthError("Google sign in failed: " + e.getMessage());
        }
    }
}
