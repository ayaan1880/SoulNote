
package com.soulnote.app.theme;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatDelegate;

public class ModernThemeManager {
    public static final int BRIGHT_MODE = 0;
    public static final int DARK_MODE = 1;
    public static final int AMOLED_MODE = 2;
    
    private static final String PREFS_NAME = "theme_prefs";
    private static final String KEY_THEME_MODE = "theme_mode";
    
    private Context context;
    private SharedPreferences prefs;
    
    public ModernThemeManager(Context context) {
        this.context = context;
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }
    
    public void setThemeMode(int mode) {
        prefs.edit().putInt(KEY_THEME_MODE, mode).apply();
        applyTheme(mode);
    }
    
    public int getCurrentThemeMode() {
        return prefs.getInt(KEY_THEME_MODE, BRIGHT_MODE);
    }
    
    public void applyCurrentTheme() {
        applyTheme(getCurrentThemeMode());
    }
    
    private void applyTheme(int mode) {
        switch (mode) {
            case BRIGHT_MODE:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            case DARK_MODE:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            case AMOLED_MODE:
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                // Additional AMOLED styling will be handled in styles
                break;
        }
    }
    
    public int getBackgroundColor() {
        switch (getCurrentThemeMode()) {
            case BRIGHT_MODE:
                return context.getResources().getColor(android.R.color.white);
            case DARK_MODE:
                return context.getResources().getColor(android.R.color.black);
            case AMOLED_MODE:
                return context.getResources().getColor(android.R.color.black);
            default:
                return context.getResources().getColor(android.R.color.white);
        }
    }
    
    public int getTextColor() {
        switch (getCurrentThemeMode()) {
            case BRIGHT_MODE:
                return context.getResources().getColor(android.R.color.black);
            case DARK_MODE:
            case AMOLED_MODE:
                return context.getResources().getColor(android.R.color.white);
            default:
                return context.getResources().getColor(android.R.color.black);
        }
    }
    
    public boolean isDarkMode() {
        return getCurrentThemeMode() != BRIGHT_MODE;
    }
}
