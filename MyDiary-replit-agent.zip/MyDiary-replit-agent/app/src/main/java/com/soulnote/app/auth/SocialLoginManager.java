
package com.soulnote.app.auth;

import android.content.Context;
import android.content.Intent;
import androidx.fragment.app.FragmentActivity;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import java.util.Arrays;

public class SocialLoginManager {
    
    public interface LoginCallback {
        void onSuccess(String provider, String userId, String email, String name);
        void onError(String error);
        void onCancel();
    }
    
    private Context context;
    private GoogleSignInClient googleSignInClient;
    private CallbackManager facebookCallbackManager;
    private LoginCallback callback;
    
    public static final int GOOGLE_SIGN_IN_REQUEST = 1001;
    
    public SocialLoginManager(Context context) {
        this.context = context;
        setupGoogleSignIn();
        setupFacebookLogin();
    }
    
    private void setupGoogleSignIn() {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestProfile()
                .build();
        
        googleSignInClient = GoogleSignIn.getClient(context, gso);
    }
    
    private void setupFacebookLogin() {
        facebookCallbackManager = CallbackManager.Factory.create();
        
        LoginManager.getInstance().registerCallback(facebookCallbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        // Handle Facebook login success
                        if (callback != null) {
                            callback.onSuccess("Facebook", 
                                loginResult.getAccessToken().getUserId(), 
                                "", // Email needs separate request
                                ""); // Name needs separate request
                        }
                    }
                    
                    @Override
                    public void onCancel() {
                        if (callback != null) callback.onCancel();
                    }
                    
                    @Override
                    public void onError(FacebookException exception) {
                        if (callback != null) callback.onError("Facebook login error: " + exception.getMessage());
                    }
                });
    }
    
    public void signInWithGoogle(FragmentActivity activity, LoginCallback callback) {
        this.callback = callback;
        Intent signInIntent = googleSignInClient.getSignInIntent();
        activity.startActivityForResult(signInIntent, GOOGLE_SIGN_IN_REQUEST);
    }
    
    public void signInWithFacebook(FragmentActivity activity, LoginCallback callback) {
        this.callback = callback;
        LoginManager.getInstance().logInWithReadPermissions(activity, 
            Arrays.asList("email", "public_profile"));
    }
    
    public void handleGoogleSignInResult(Intent data) {
        Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
        try {
            GoogleSignInAccount account = task.getResult(ApiException.class);
            if (callback != null) {
                callback.onSuccess("Google", 
                    account.getId(), 
                    account.getEmail(), 
                    account.getDisplayName());
            }
        } catch (ApiException e) {
            if (callback != null) {
                callback.onError("Google sign in failed: " + e.getMessage());
            }
        }
    }
    
    public void handleFacebookResult(int requestCode, int resultCode, Intent data) {
        facebookCallbackManager.onActivityResult(requestCode, resultCode, data);
    }
    
    public void signOut() {
        // Sign out from Google
        googleSignInClient.signOut();
        
        // Sign out from Facebook
        LoginManager.getInstance().logOut();
    }
}
