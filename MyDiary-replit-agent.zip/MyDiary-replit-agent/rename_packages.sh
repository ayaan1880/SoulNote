
#!/bin/bash

echo "Renaming packages from kiminonawa.mydiary to soulnote.app..."

# Find all Java files and update package declarations
find app/src -name "*.java" -type f -exec sed -i 's/package com\.kiminonawa\.mydiary/package com.soulnote.app/g' {} \;

# Find all Java files and update import statements
find app/src -name "*.java" -type f -exec sed -i 's/import com\.kiminonawa\.mydiary/import com.soulnote.app/g' {} \;

# Find all XML files and update package references
find app/src -name "*.xml" -type f -exec sed -i 's/com\.kiminonawa\.mydiary/com.soulnote.app/g' {} \;

# Update any remaining references in other files
find . -name "*.gradle" -type f -exec sed -i 's/com\.kiminonawa\.mydiary/com.soulnote.app/g' {} \;
find . -name "*.md" -type f -exec sed -i 's/MyDiary/SoulNote/g' {} \;
find . -name "*.md" -type f -exec sed -i 's/kiminonawa\.mydiary/soulnote.app/g' {} \;

echo "Package renaming completed!"
