#Privacy Policy

In "MyDiary" , all data only save in local in current version , I can't and don't get any text or photo from your devices.

#隱私權政策

在"MyDiary"中，現行的版本所有資料只會儲存在本地端，我不能也不會取得你的任何文字和圖片資料。
# Privacy Policy for SoulNote

**Last updated: December 2024**

## Introduction

SoulNote ("we", "our", or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and safeguard your information when you use our mobile application.

## Information We Collect

### Information You Provide
- **Diary Entries**: Text content, photos, and metadata you create
- **Account Information**: Name, email address (if you choose to register)
- **Settings and Preferences**: Theme choices, notification settings

### Automatically Collected Information
- **Device Information**: Device model, operating system version
- **Usage Analytics**: App usage patterns (anonymized)
- **Crash Reports**: Technical data to improve app stability

## How We Use Your Information

### Primary Uses
- **Core Functionality**: Store and display your diary entries
- **Synchronization**: Backup data across your devices (if enabled)
- **Personalization**: Customize your app experience

### Secondary Uses
- **Improvement**: Analyze usage patterns to enhance features
- **Support**: Provide technical assistance when needed
- **Security**: Protect against unauthorized access

## Data Storage and Security

### Local Storage
- All diary entries are stored locally on your device
- Sensitive data is encrypted using AES-256-GCM encryption
- Encryption keys are stored in Android Keystore

### Cloud Storage (Optional)
- Encrypted backups to Google Drive (user-controlled)
- Data transmitted over HTTPS
- You can disable cloud features at any time

## Data Sharing

### We Do Not Sell Your Data
SoulNote will never sell, rent, or trade your personal information.

### Limited Sharing Scenarios
- **Legal Requirements**: When required by law or legal process
- **Service Providers**: Encrypted data with trusted cloud providers (Google Drive)
- **Security**: To investigate fraud or security issues

## Your Rights and Controls

### Access and Control
- **View**: Access all your stored data within the app
- **Export**: Download your data in multiple formats
- **Delete**: Remove individual entries or all data
- **Encryption**: Enable/disable encryption for entries

### Account Management
- **Login Options**: Use social login or remain anonymous
- **Data Portability**: Export data to move to other services
- **Account Deletion**: Permanently delete your account and data

## Third-Party Services

### Integrated Services
- **Google Services**: Authentication, Drive backup, location services
- **Facebook SDK**: Social authentication (optional)
- **AI Services**: Mood analysis and writing prompts (optional)

### Third-Party Privacy
Each service has its own privacy policy. We recommend reviewing:
- [Google Privacy Policy](https://policies.google.com/privacy)
- [Facebook Privacy Policy](https://www.facebook.com/privacy/policy)

## Children's Privacy

SoulNote is not intended for children under 13. We do not knowingly collect personal information from children under 13. If you believe we have collected such information, please contact us immediately.

## International Data Transfers

Your data may be transferred to and processed in countries other than your own. We ensure appropriate safeguards are in place to protect your information.

## Data Retention

### Active Data
- Data is retained as long as you use the app
- You can delete data at any time

### Deleted Data
- Deleted data is permanently removed from our systems
- Backup copies are deleted within 30 days

## Changes to Privacy Policy

We may update this Privacy Policy periodically. We will notify you of significant changes through:
- In-app notifications
- Email (if you provided one)
- App store update notes

## Security Measures

### Technical Safeguards
- End-to-end encryption for sensitive data
- Secure transmission protocols (HTTPS)
- Regular security audits and updates

### Access Controls
- Biometric authentication support
- Session management and timeout
- Secure key storage

## Contact Us

If you have questions about this Privacy Policy or our data practices:

- **Email**: privacy@soulnote.app
- **GitHub**: [Issues](https://github.com/yourusername/SoulNote/issues)
- **In-App**: Use the feedback option in settings

## Consent

By using SoulNote, you consent to this Privacy Policy. If you do not agree with our practices, please do not use our app.

---

**Your privacy matters to us. SoulNote is designed to keep your thoughts secure and private.**
