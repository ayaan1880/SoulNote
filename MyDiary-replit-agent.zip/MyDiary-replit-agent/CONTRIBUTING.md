
# Contributing to SoulNote

Thank you for your interest in contributing to SoulNote! We welcome contributions from the community and are grateful for any help you can provide.

## Getting Started

### Prerequisites
- Android Studio Arctic Fox or newer
- Android SDK 33
- Java 11 or higher
- Git

### Setting Up Development Environment
1. Fork the repository
2. Clone your fork: `git clone https://github.com/yourusername/SoulNote.git`
3. Open the project in Android Studio
4. Build the project: `./gradlew assembleDebug`

## How to Contribute

### Reporting Bugs
1. Check if the bug has already been reported in [Issues](https://github.com/yourusername/SoulNote/issues)
2. If not, create a new issue with:
   - Clear bug description
   - Steps to reproduce
   - Expected vs actual behavior
   - Device information and Android version
   - Screenshots if applicable

### Suggesting Features
1. Check existing [Issues](https://github.com/yourusername/SoulNote/issues) for similar suggestions
2. Create a new issue with:
   - Clear feature description
   - Use case and benefits
   - Mockups or examples if applicable

### Submitting Code Changes
1. Create a new branch: `git checkout -b feature/your-feature-name`
2. Make your changes following our coding standards
3. Test your changes thoroughly
4. Commit with clear messages: `git commit -m "Add feature: description"`
5. Push to your fork: `git push origin feature/your-feature-name`
6. Create a Pull Request

## Coding Standards

### Java Style Guidelines
- Follow Android development best practices
- Use clear, descriptive variable and method names
- Add comments for complex logic
- Keep methods small and focused
- Use proper exception handling

### Security Guidelines
- Never commit API keys or sensitive data
- Follow secure coding practices
- Encrypt sensitive user data
- Validate all user inputs

### Testing
- Write unit tests for new features
- Test on multiple devices and Android versions
- Ensure accessibility compliance
- Test offline functionality

## Code Review Process

1. All submissions require review before merging
2. Maintainers will review code for:
   - Functionality and correctness
   - Security implications
   - Performance impact
   - Code quality and style
   - Test coverage

## Community Guidelines

### Be Respectful
- Use welcoming and inclusive language
- Respect different viewpoints and experiences
- Accept constructive criticism gracefully
- Focus on what's best for the community

### Be Collaborative
- Help others learn and grow
- Share knowledge and resources
- Provide constructive feedback
- Support fellow contributors

## Getting Help

- Join our [Discussions](https://github.com/yourusername/SoulNote/discussions)
- Check the [Wiki](https://github.com/yourusername/SoulNote/wiki) for documentation
- Ask questions in Issues with the "question" label

## Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes for significant contributions
- Special mentions for outstanding contributions

Thank you for helping make SoulNote better for everyone! 🙏
